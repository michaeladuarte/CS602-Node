<?php

function pr_dump($var) { 
	print '<pre>'; print_r($var); print '</pre>'; 
}

?>
