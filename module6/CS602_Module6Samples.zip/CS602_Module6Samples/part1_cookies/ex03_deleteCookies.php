<?php


	/* set expiration to 1 hour ago */
setcookie("CourseName1", "", 
	time()-3600, "/cs602");  

?>