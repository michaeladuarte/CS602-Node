<?php

setcookie("course[id]", "cs602");
setcookie("course[name]", "Server Side Web Development");
setcookie("course[term]", "Spring");

?>