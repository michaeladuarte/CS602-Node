<?php

include('../common.inc.php');

	$array = array('apples' => 3, 'bananas' => 5, 'oranges' => 1);
	echo json_encode($array);
	
?>