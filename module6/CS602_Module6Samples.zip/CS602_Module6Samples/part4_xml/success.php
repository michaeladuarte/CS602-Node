<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8" />
    <title>Success</title>
</head>
<body>
    <h1>Success!</h1>
	<p>The student was added!</p>

	<?php
		include("view.php");
	?>
</body>
</html>