<?php include 'view/header.php'; ?>
<main>
    <h1>Error</h1>
    <p><?php $error_message; ?></p>
</main>
<?php include 'view/footer.php'; ?>