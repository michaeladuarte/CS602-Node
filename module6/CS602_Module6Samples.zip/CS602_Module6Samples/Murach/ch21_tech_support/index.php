<?php include 'view/header.php'; ?>
<main>
    <h2>Main Menu</h2>
    <nav>
    <ul>
        <li><a href="admin">Administrators</a></li>
        <li><a href="incident_update">Technicians</a></li>
        <li><a href="product_register">Customers</a></li>
    </ul>
    </nav>
</main>
<?php include 'view/footer.php'; ?>