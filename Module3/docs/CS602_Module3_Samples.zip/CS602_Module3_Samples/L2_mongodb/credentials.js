module.exports = {
	//host:     'localhost',
	//port: 		'27017',
	host:     'ds115768.mlab.com',
	port: 		'15768',
	username: 'cs602_user',
	password: 'cs602_secret',
	database: 'cs602db'
}

