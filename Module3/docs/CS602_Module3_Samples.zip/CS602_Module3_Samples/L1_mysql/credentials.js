module.exports = {
	host:     'localhost',
	// host:     'db4free.net',
	username: 'cs602_user',
	password: 'cs602_secret',
	database: 'cs602db'
}
