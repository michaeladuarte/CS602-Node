module.exports = 
	function addCourse(req , res , next){
	  	res.render('addCourseView', 
	  		{title:"Add a Course"});
};
