function addCourse(){
    window.location.href = '/courses/add';
}

function cancelAdd(){
    window.location.href = '/courses';
}

