module.exports = function () {
  return {
		firstName: 'John',
		lastName:  'Smith'
	};
};

