var colors = require('colors');

var data = 'Welcome to CS602!';

console.log(data.green); 
console.log(data.underline.red) ;
console.log(data.bold.red);
console.log(data.inverse); 
console.log(data.rainbow); 

