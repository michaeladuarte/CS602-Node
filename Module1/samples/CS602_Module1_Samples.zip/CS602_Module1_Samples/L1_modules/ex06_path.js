var path = require('path');

var input = __filename;

console.log(path.dirname(input));

console.log(path.basename(input));

console.log(path.extname(input));

