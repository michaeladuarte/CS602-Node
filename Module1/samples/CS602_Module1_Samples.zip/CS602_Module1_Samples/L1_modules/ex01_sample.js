var foo = require('./ex01_foo');
foo();
