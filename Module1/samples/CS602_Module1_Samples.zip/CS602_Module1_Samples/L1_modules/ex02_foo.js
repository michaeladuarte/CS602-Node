module.exports = {
	firstName: 'John',
	lastName:  'Smith'
};

