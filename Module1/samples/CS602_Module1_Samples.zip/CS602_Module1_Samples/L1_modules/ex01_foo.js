module.exports = function () {
  console.log('Function in module...');
};
