module.exports = () => {
  return {
		firstName: 'John',
		lastName:  'Smith'
	};
};

